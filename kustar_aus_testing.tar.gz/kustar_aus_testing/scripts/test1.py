#!/usr/bin/env python

import rospy		#importing ROS python library
from sensor_msgs.msg import LaserScan	#importing LaserScan class. LaserScan class is basically the message definetion for the laser data 
#please check this link http://docs.ros.org/api/sensor_msgs/html/msg/LaserScan.html it will show you what this class contains.

#this is a function that is called everytime the node recieves a laser message
def callBack(data):
	#here I'm just storing data into the global object LaserData. So we can use it in our main code
	#It's a good practice if you make your call back function as short as possible
	global LaserData
	LaserData=data

#Here starts the code

#first we initalize this script as a ROS node. So the ROS master can record it as a node in its network. 
#ROS master is the process (or the node) you run when you write "roscore" in the terminal
#read about what the ROS master node does from this link: http://wiki.ros.org/roscore 
#also read this: http://wiki.ros.org/Master (just read section 1-overview)

rospy.init_node('test1', anonymous=False)


#Ok, we need to subscribe for the laser data in order to receive them
#We call the Subscriber and give it the following arguments:
#1-Topic name: the topic on which th data are published (or sent)
#2-Message type: Type of the message. In our case it's the LaserScan 
#3- function name: the function that should be called when data is received
rospy.Subscriber('/base_scan', LaserScan, callBack)

#we define an instance of rospy.Rate. This has a function called sleep() which you can use to make your loop run at 
#a desired rate. I chose 0.5 Hz = a delay of 2 seconds is maintained.
#according to http://wiki.ros.org/rospy/Overview/Time this is what they say:
#"rospy provides a rospy.Rate convenience class which makes a best effort at maintaining a particular rate for a loop. "
rate = rospy.Rate(0.5)

#we define LaserData instance so we can store the data in it
LaserData=LaserScan()

#main loop. Your acctual code start here. 
# rospy.is_shutdown(), i can make it "while True" instead. But if I do that you will not be able to stop the node
# unless you close the terminal. But using "is_shutdown()", you can break the node from looping by "ctrl+c" (break operaion)
# not becuase we want it to keep running unless it's shutdown (they didn't make a function is_alive() !)
while not rospy.is_shutdown():

#here I print some of LaserScan class memebers. Which are basiclally just variables
	print 'minimum angle (rads)= ',LaserData.angle_min
	print 'maximum angle (rads)= ',LaserData.angle_max
	print 'maximum angle (rads)= ',LaserData.angle_increment
	
	print '------------------'
	
	
	#call sleep() function which will ensure the loop is always taking 2 seconds 
	#If your loop needs 1 sec. It will cause a delay of 1 sec. This ensures the rate you chose before is satisfied
	rate.sleep()
