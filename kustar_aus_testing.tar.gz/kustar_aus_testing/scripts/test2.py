#!/usr/bin/env python

import rospy		
from sensor_msgs.msg import LaserScan	
def callBack(data):
	global LaserData
	LaserData=data


rospy.init_node('test1', anonymous=False)


rospy.Subscriber('/base_scan', LaserScan, callBack)

rate = rospy.Rate(0.5)

LaserData=LaserScan()


while not rospy.is_shutdown():
	if len(LaserData.ranges)>0:
		print LaserData.ranges  #range data from the laser message
		
	rate.sleep()
